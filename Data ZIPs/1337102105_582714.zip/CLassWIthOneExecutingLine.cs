/* This program is written to demonstrate using comments
*/
class ClassWithOneExecutingLine
{
   static void Main()
   {
      // The next line writes the message
      System.Console.WriteLine("Message");
   }  // End of Main
}  // End of ClassWithOneExecutingLine