/*
   Program Made by: Not me
   Program Date: 1/24/2019
   Program Description: Debug file #4 downloaded for class
   Issues Encountered:
      Line 20: Missing Semi-colon
      Line 21: WriteLine() spelled as WriteLien()
      Line 24: WriteLine() spelled as Writeline()
      Lines 23 && 25: Missing beginning double quote
      Line 26: Extra closing curly bracket
*/

using static System.Console;
class DebugOne4
{
   static void Main()
   {
      WriteLine("How to play tic tac toe:");
      WriteLine("Draw a three by three grid.");
      WriteLine("The first player puts an X in any of the nine locations.");
      WriteLine("The second player puts an O in any remaining location.");
      WriteLine("Players alternate turns until one has three of the same symbol in a row");
      WriteLine("    vertically, horizontally, or diagonally.");
      WriteLine("If all nine squares are filled without three in a row,");
      WriteLine("    the game ends in a tie.");
   }
}

