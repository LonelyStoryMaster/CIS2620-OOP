/*
   Program Made by: Not me
   Program Date: 1/24/2019
   Program Description: Debug file #1 downloaded for class
   Issues Encountered:
      Line 17: WriteLine() spelled with lowercase "l"
      Line 19: Semi-colon missing
      Line 20: Extra opening parenthesis
      Line 21: Missing closing double quotation
*/

using static System.Console;
class DebugOne1
{
   static void Main()
   {
      WriteLine("This program displays some keyboard punctuation");
      WriteLine("!   exclamation point");
      WriteLine("@   at-sign");
      WriteLine("#   pound sign or hash mark");
      WriteLine("$   dollar sign");
   }
}

