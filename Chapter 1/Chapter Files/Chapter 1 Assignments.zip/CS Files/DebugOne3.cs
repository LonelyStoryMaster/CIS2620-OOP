/*
   Program Made by: Not me
   Program Date: 1/24/2019
   Program Description: Debug file #3 downloaded for class
   Issues Encountered:
      Line 12: class spelled as classs
      Line 14: Main() spelled as Mane()
      Lines 17-21: To print vertically, WriteLine() is to be used not Write()
*/

using static System.Console;
class DebugOne3
{
   static void Main()
   {
      WriteLine("This program lists the number 1 to 5 vertically");
      WriteLine("1");
      WriteLine("2");
      WriteLine("3");
      WriteLine("4");
      WriteLine("5");
   }
}

