/*
   Program Made by: Not me
   Program Date: 1/24/2019
   Program Description: Debug file #1 downloaded for class
   Issues Encountered:
      Line 14: Missing end double quotation
      Line 18: WriteLine() misspelled
      Line 19: WriteLine() misspelled
      Lines 20-22: Missing beginning quotation
      Line 21: Missing closing curly bracket for Main()
*/

using static System.Console;
class DebugOne2
{
   static void Main()
   {
      WriteLine("This program displays a square");
      WriteLine("&&&&&&&&&&");
      WriteLine("&        &");
      WriteLine("&        &");
      WriteLine("&        &");
      WriteLine("&&&&&&&&&&");
   }
}

