using static System.Console;

class Hello
{
    static void Main()
    {
        WriteLine("Hello World!");
    }
}